#ifndef ARDUINO_MOTOR_CONTROL_H_
#define ARDUINO_MOTOR_CONTROL_H_

#include "PID_v1.h"
#include "commands.h"

#define RX_PIN 158 // Yellow, goes to TX on Udoo
#define TX_PIN 159 // Orange, goes to RX on Udoo
#define WHEEL_DIAMETER 100 // 100mm
#define SERIAL_BUFFER_LEN 32

#define DIST_MODE 0
#define VEL_MODE 1


//CHRIS FIX THIS
/*const String dist_locomotion_mode = "dist_mode";
const String vel_locomotion_mode = "vel_mode";

String current_locomotion_mode = vel_locomotion_mode;
*/
int current_mode = VEL_MODE;

int PID_output_lower = 0;
int PID_output_upper = 255;

/* Encoder PID control */
double PID1_input = 0;
double PID1_output = 0;
double PID1_target = 0;

double PID2_input = 0;
double PID2_output = 0;
double PID2_target = 0;

double Kp = 0.25;
double Ki = 0.1;
double Kd = 0.005;

/* Velocity PID control */
double vPID1_input = 0;
double vPID1_output = 0;
double vPID1_target = 0;

double vPID2_input = 0;
double vPID2_output = 0;
double vPID2_target = 0;

double vKp = 0.15;
double vKi = 0.1;
double vKd = 0.005;


PID enc1PID(&PID1_input, &PID1_output, &PID1_target, Kp, Ki, Kd, DIRECT);
PID enc2PID(&PID2_input, &PID2_output, &PID2_target, Kp, Ki, Kd, DIRECT);

PID v1PID(&vPID1_input, &vPID1_output, &vPID1_target, vKp, vKi, vKd, DIRECT);
PID v2PID(&vPID2_input, &vPID2_output, &vPID2_target, vKp, vKi, vKd, DIRECT);

// Contains the serial output
char serial1_buffer[SERIAL_BUFFER_LEN];
int serial1_buffer_position = 0;

int E_D_PID(long encodertarget, long encoder);

#endif
